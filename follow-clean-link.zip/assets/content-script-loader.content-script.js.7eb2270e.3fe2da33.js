(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.js.7eb2270e.js")
    );
  })().catch(console.error);

})();
